﻿
using consumingAPI.models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Net;
using System.Security.Principal;


namespace consumingAPI.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
      
        string basURl = "https://jsonplaceholder.typicode.com/";
      

        public object FiddleHelper { get; private set; }

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public async Task<ActionResult> Index()
        {
            List<employee> EmpInfo = new List<employee>();
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(basURl);
                client.DefaultRequestHeaders.Clear();
                HttpResponseMessage Res = await client.GetAsync("/todos/1");
                if (Res.IsSuccessStatusCode)
                {
                    var EmpResponse = Res.Content.ReadAsStringAsync().Result;
                    EmpInfo = JsonConvert.SerializeObject(EmpInfo);
                }
                return View(EmpInfo);
            }
        }



    }
}




