﻿using System.Collections.Generic;
using System.Linq;
using System.Web;


namespace consumingAPI.models
{
    public class employee
    {
        public int userId { get; set; }
       
    }
}
