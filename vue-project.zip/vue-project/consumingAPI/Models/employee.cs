﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


namespace consumingAPI.models
{
    public class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string city { get; set; }
        public string EmailID { get; set; }
        public long Salary { get; set; }
    }
}
