﻿namespace WebApi.Services
{
    public interface IWebApiService
    {
        Task<List<Movie>> GetMovie(string countryCode, int year);
    }
}
