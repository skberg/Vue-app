﻿using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Text.Json;

namespace WebApi.Services
{
    public class WebApiService : IWebApiService
    {
        private readonly HttpClient client;

        public WebApiService(IHttpClientFactory clientFactory)
        {
            client = clientFactory.CreateClient("MovieApi");
        }

        public async Task<List<Movie>> GetMovie(string countryCode, int year)
        {
            var url = string.Format("/", year, countryCode);
            var result = new List<Movie>();
            var response = await client.GetAsync(url);

            



            if (response.IsSuccessStatusCode)
            {
                var stringResponse = await response.Content.ReadAsStringAsync();

                result = JsonSerializer.Deserialize<List<Movie>>(stringResponse,
                    new JsonSerializerOptions() { PropertyNamingPolicy = JsonNamingPolicy.CamelCase });
            }
            else
            {
                throw new HttpRequestException(response.ReasonPhrase);
            }

            return result;
        }
    }
}
