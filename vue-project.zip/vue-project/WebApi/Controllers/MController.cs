using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Data;
using System.Diagnostics;
using System.Net;
using System.Net.Http.Headers;

namespace WebApi.Controllers
{
    public class MController : Controller
    {
        private readonly ILogger<MController> _logger;
       

        public object creditReformModel { get; private set; }

        public MController(ILogger<MController> logger)
        {
            _logger = logger;
        }

        public async Task<IActionResult> Index()
        {
            //calling the web api and populating in views using datatable
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        private class ErrorViewModel
        {
            public string RequestId { get; set; }
        }
    }
}



