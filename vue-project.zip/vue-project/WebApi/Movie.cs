namespace WebApi
{
    public class Movie
    {
              public string? Summary { get; set; }
    }
  


}